# Pull to Refresh

Firefox Addon for refreshing page on Pull Down gesture.

Tested only on Android and Windows 10.

Icon made by Freepik perfect from www.flaticon.com.