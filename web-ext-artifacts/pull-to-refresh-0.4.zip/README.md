# Pull to Refresh

Firefox Addon for refreshing page on Pull Down gesture