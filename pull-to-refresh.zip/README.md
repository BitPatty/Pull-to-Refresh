# Reload, Back, Forward - Swipe Gestures

- Pull down gesture (vertical swipe) to Reload page.
- Swipe horizontally to the left margin of the screen to go Back
- Swipe horizontally to the right margin of the screen to go Forward 

There are no visual indicators during the gesture.

Tested on Android and Windows 10.


Icon made by **Freepik** from **www.flaticon.com**.